<?php
require_once './modelo/db.php';
require_once './vista/vista.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    $viaje = obtenerDetalleViaje($id);
    mostrarDetalle($viaje);
}