<?php
function devolverbd() {
    $db = new PDO('mysql:host=localhost;dbname=db_tp146;charset=utf8', 'root', '');
    $query = $db->prepare('SELECT * FROM viaje');
    $query->execute();
    return $query->fetchAll(PDO::FETCH_OBJ);
}

function obtenerDetalleViaje($id) {
        $db = new PDO('mysql:host=localhost;dbname=db_tp146;charset=utf8', 'root', '');
        $query = $db->prepare('SELECT * FROM viaje WHERE id_viaje = ?');
        $query->execute([$id]);
        return $query->fetch(PDO::FETCH_OBJ);
}

function agregarViaje($origen, $destino, $fecha_viaje, $id_colectivo) {
    $db = new PDO('mysql:host=localhost;dbname=db_tp146;charset=utf8', 'root', '');
    $query = $db->prepare('INSERT INTO viaje (origen, destino, fecha_viaje, id_colectivo) VALUES (?, ?, ?, ?)');
    $query->execute([$origen, $destino, $fecha_viaje, $id_colectivo]);
}

function eliminarViaje($id) {
    $db = new PDO('mysql:host=localhost;dbname=db_tp146;charset=utf8', 'root', '');
    $query = $db->prepare('DELETE FROM viaje WHERE id_viaje = ?');
    $query->execute([$id]);
}

function actualizarViaje($id, $origen, $destino, $fecha_viaje, $id_colectivo) {
    $db = new PDO('mysql:host=localhost;dbname=db_tp146;charset=utf8', 'root', '');
    $query = $db->prepare('UPDATE viaje SET origen = ?, destino = ?, fecha_viaje = ?, id_colectivo = ? WHERE id_viaje = ?');
    $query->execute([$origen, $destino, $fecha_viaje, $id_colectivo, $id]);
}
