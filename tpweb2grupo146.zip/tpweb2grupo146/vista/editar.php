<?php
require_once '../modelo/db.php';

if (isset($_GET['id_viaje'])) {
    $id_viaje = $_GET['id_viaje'];
    $viaje = obtenerDetalleViaje($id_viaje);
} else {
    header('Location: admin.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Viaje</title>
</head>
<body>
    <h1>Editar Viaje</h1>
    <form method="POST" action="../controlador/ControladorViaje.php">
        <input type="hidden" name="id_viaje" value="<?php echo $viaje->id_viaje; ?>">
        <label for="origen">Origen:</label>
        <input type="text" id="origen" name="origen" value="<?php echo $viaje->origen; ?>" required>
        <br>
        <label for="destino">Destino:</label>
        <input type="text" id="destino" name="destino" value="<?php echo $viaje->destino; ?>" required>
        <br>
        <label for="fecha_viaje">Fecha del viaje:</label>
        <input type="date" id="fecha_viaje" name="fecha_viaje" value="<?php echo $viaje->fecha_viaje; ?>" required>
        <br>
        <label for="id_colectivo">Número de colectivo:</label>
        <input type="number" id="id_colectivo" name="id_colectivo" value="<?php echo $viaje->id_colectivo; ?>" required>
        <br>
        <button type="submit" name="actualizar">Actualizar Viaje</button>
    </form>
    <a href="admin.php">Volver a la lista</a>
</body>
</html>
