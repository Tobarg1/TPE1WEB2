<?php

function mostrarVista($viajes) {
    require __DIR__ . '/../template/mostrarviajes.phtml';
}

function mostrarDetalle($viaje) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Detalle del Viaje</title>
    </head>
    <body>
        <h1>Detalle del Viaje</h1>
        <p>Origen: <?php echo $viaje->origen; ?></p>
        <p>Destino:<?php echo $viaje->destino; ?></p>
        <p>Fecha del Viaje: <?php echo $viaje->fecha_viaje; ?></p>
        <p>Numero del colectivo <?php echo $viaje->id_colectivo; ?></p>
        <a href="viajes.php">Volver a la lista</a>
    </body>
    </html>
    <?php
}