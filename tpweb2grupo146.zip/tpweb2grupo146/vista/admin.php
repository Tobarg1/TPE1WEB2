<?php
require_once '../modelo/db.php'; 
$viajes = devolverbd(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Viajes</title>
</head>
<body>
    <h1>Estas en Admin</h1>

    <h2>Agregar Nuevo Viaje</h2>

    <form method="POST" action="../controlador/controladorViaje.php">
    <label for="origen">Origen:</label>
    <input type="text" id="origen" name="origen" required>
    <br>
    <label for="destino">Destino:</label>
    <input type="text" id="destino" name="destino" required>
    <br>
    <label for="fecha_viaje">Fecha del viaje:</label>
    <input type="date" id="fecha_viaje" name="fecha_viaje" required>
    <br>
    <label for="id_colectivo">Número de colectivo:</label>
    <input type="number" id="id_colectivo" name="id_colectivo" required>
    <br>
    <button type="submit" name="agregar">Agregar Viaje</button>
</form>
<h2>Ver Lista y Modificar</h2>
    <table>
        <thead>
            <tr>
                <th>Numero del viaje</th>
                <th>Origen</th>
                <th>Destino</th>
                <th>Fecha del viaje</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($viajes as $viaje) { ?>
                <tr>
                    <td><?php echo $viaje->id_viaje; ?></td>
                    <td><?php echo $viaje->origen; ?></td>
                    <td><?php echo $viaje->destino; ?></td>
                    <td><?php echo $viaje->fecha_viaje; ?></td>
                    <td>
                        <form method="POST" action="../controlador/ControladorViaje.php" style="display:inline;">
                            <input type="hidden" name="id_viaje" value="<?php echo $viaje->id_viaje; ?>">
                            <button type="submit" name="eliminar">Eliminar</button>
                        </form>
                        <form method="GET" action="editar.php" style="display:inline;">
                            <input type="hidden" name="id_viaje" value="<?php echo $viaje->id_viaje; ?>">
                            <button type="submit">Modificar</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
