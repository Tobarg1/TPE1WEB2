<?php
require_once './modelo/db.php'; 
require_once './vista/vista.php';
$viajes = devolverbd(); 
mostrarVista($viajes);
 