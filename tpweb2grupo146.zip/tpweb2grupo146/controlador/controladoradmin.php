<?php 
class ControladorAdmin {
    function login($username, $password) {
        if ($username === 'webadmin' && $password === 'admin') {
            session_start();
            $_SESSION['admin_logged'] = true;
            header('Location: ./vista/admin.php');
            exit();
        } else {
            return "Usuario o contraseña incorrectos.";
        }
    }
}
