<?php
require_once '../modelo/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['eliminar'])) {
        $id_viaje = $_POST['id_viaje'];
        eliminarViaje($id_viaje);
        header('Location: ../vista/admin.php'); 

        exit();
    }

    if (isset($_POST['actualizar'])) {
        $id_viaje = $_POST['id_viaje'];
        $origen = $_POST['origen'];
        $destino = $_POST['destino'];
        $fecha_viaje = $_POST['fecha_viaje'];
        $id_colectivo = $_POST['id_colectivo'];

        actualizarViaje($id_viaje, $origen, $destino, $fecha_viaje, $id_colectivo);
        header('Location: ../vista/admin.php'); 

        exit();
    }

    if (isset($_POST['agregar'])) {
        $origen = $_POST['origen'];
        $destino = $_POST['destino'];
        $fecha_viaje = $_POST['fecha_viaje'];
        $id_colectivo = $_POST['id_colectivo'];

        agregarViaje($origen, $destino, $fecha_viaje, $id_colectivo);
        header('Location: ../vista/admin.php'); 

        exit();
    }
}
